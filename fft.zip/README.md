#HOW TO INSTALL (DEFAULT or BASIC USAGE)
---
	* git clone https://github.com/SecretSyntax/insta-tools.git
	* cd insta-tools
	* unzip node_modules.zip
	* node index.js
	* Then select the tool you want to use!
<br/>

#INFORMATION:
---
	* dellallphoto		(WORK & TESTED)
	* fah			(WORK & TESTED)
	* fftauto		(WORK & TESTED)
	* flaauto		(WORK & TESTED)
	* flmauto		(WORK & TESTED)
	* unfollall		(WORK & TESTED)
	* unfollnotfollback	(WORK & TESTED)
	* botlike		(WORK & TESTED)
	* botlike2		(WORK & TESTED)
<br/>

#WARNING
---
	"Use tools at your own risk!!!"
	"Use this Tool for personal use, not for sale!!!"
	"Make sure your account is not in private to use this tool!!!"
<br/>

#UPDATE
---
	1. Fix Error No Detect Followers Target
	2. Input Total of Target You Want (ITTYW)
	3. + Improvements In Display Program
<br/>

#SPECIAL THANKS TO:
---
	* Code by Ccocot (ccocot@bc0de.net)
	* Fixing and Testing by Putu Syntax
	* BC0DE.NET | NAONLAH.NET - WingKocoli
